"use strict";

let inputArray = [];
let inputText = "";

function displayInputPressionAndResult(text = "") {
    let displayStr = text.replace('/', '&divide;');
  let element = document.querySelector(".inputPressionText");
  element.innerHTML = displayStr;
}

function displayInputIntText(text = "0") {
  if (text == "") {
    text = "0";
  }
  let element = document.querySelector(".inputAndResultText");
  element.innerHTML = text;
}

function onButtonClick(event) {
  const dataset = event.target.dataset;
  const key = dataset.key;
  const value = dataset.value;

  if (key == null || value == null) {
    return;
  }

  switch (key) {
    case "operator":
      operatorButtonClick(value);
      break;

    case "number":
      numberButtonClick(value);
      break;

    case "all-clear":
      allClearButtonClick();
      break;

    case "clear":
      clearButtonClick();
      break;

    case "decimal":
      decimalButtonClick(value);
      break;

    case "equal":
      equalButtonClick();
      break;

    default:
      allClearButtonClick();
      break;
  }
}

function operatorButtonClick(value) {
  if (inputArray.length == 0 && inputText == "") {
    return;
  }

  if (inputText == "") {
    inputArray.pop();
    inputArray.push(value);
    displayInputPressionAndResult(inputArray.join(" "));
    return;
  }

  inputArray.push(inputText);
  inputArray.push(value);
  displayInputPressionAndResult(inputArray.join(" "));

  inputText = "";
  displayInputIntText(inputText);
}

function numberButtonClick(value) {
  if (Number(value) === 0 && inputText == "0") {
    return;
  }
  let newInputNumberText =
    (inputText == "0" && Number(value) > 0) ? value : inputText.concat("", value);

  inputText = newInputNumberText;
  displayInputIntText(newInputNumberText);
  displayInputPressionAndResult(inputArray.join(" ") + " " + inputText);
}

function decimalButtonClick(value) {
  let tempNumberStr = inputText.concat("", value).concat("", "0");
  let isInt = isDecimal(tempNumberStr);
  if (!isInt) {
    return;
  }
  let newInputDecialText = inputText.concat("", value);
  inputText = newInputDecialText;
  displayInputIntText(newInputDecialText);
}

function equalButtonClick() {
  if (inputText == "") {
    inputArray.pop();
  } else {
    inputArray.push(inputText);
  }
  let inputStr = inputArray.join(" ");
  let result = eval(inputStr);
  inputText = "";
  inputArray = [];
  displayInputPressionAndResult(`${inputStr} = ${result}`);

  if (result === Infinity){
      alert('결과값이 너무 큽니다.(Infinity)');
  }
}

function clearButtonClick() {
  inputText = "";
  displayInputIntText(inputText);
  displayInputPressionAndResult(inputArray.join(" "));
}

function allClearButtonClick() {
  inputArray = [];
  inputText = "";
  displayInputPressionAndResult(inputArray.join(" "));
  displayInputIntText(inputText);
}

function isDecimal(str) {
  return !isNaN(str) && Number.isInteger(parseFloat(str));
}

function setEventListeners() {
  const container = document.querySelector(".container");
  container.addEventListener("click", (event) => onButtonClick(event));
}

displayInputPressionAndResult(inputArray.join(" "));
displayInputIntText();
setEventListeners();
